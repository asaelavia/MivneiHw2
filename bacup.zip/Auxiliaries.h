//
// Created by Avia on 28/11/2019.
//

#ifndef HW2_AUXILIARIES_H
#define HW2_AUXILIARIES_H

template<typename T>
class Node {
public:
    Node *next;
    Node *prev;
    T data;
};

template<typename T>
class LinkedList {
    int length;
public:
    Node<T> *head;
    Node<T> *tail;

    LinkedList<T>();

    ~LinkedList<T>();

    void add(T data);

    T getFirst();

    void removeFirst();

    void removeNode(Node<T> *node);

    int getListSize() const;

    bool isListEmpty();

};

#endif //HW2_AUXILIARIES_H
