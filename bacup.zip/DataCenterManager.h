//
// Created by Avia on 28/11/2019.
//

#ifndef HW2_DATACENTERMANAGER_H
#define HW2_DATACENTERMANAGER_H


class DataCenterManager {


};


#endif //HW2_DATACENTERMANAGER_H
