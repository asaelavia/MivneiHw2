//
// Created by Avia on 28/11/2019.
//

#ifndef HW2_DATACENTER_H
#define HW2_DATACENTER_H

#include "Auxiliaries.h"
#include "library1.h"

class DataCenter {
    class ServerData {
    private:
        int serverId;
        bool occupied = false;
        int os = 0;
        Node<ServerData *> *listPointer;
    public:

        ServerData(ServerData &) = delete;

        ServerData();

        ~ServerData();

        void setServerId(int serverId);

        int getServerId() const;

        void setListPointer(Node<ServerData *> *listPointer);

        Node<ServerData *> *getListPointer() const;


        bool getOccupied() const;

        void setOccupied(bool occupied);

        int getOs() const;

        void setOs(int os);

    };

private:
    int dataCenterid;
    int numOfServersInDb;
    int linuxCounter;
    int windowsCounter;
    LinkedList<ServerData *> linuxServers;
    LinkedList<ServerData *> windowsServers;
    ServerData *serversArray;
public:
    DataCenter() = default;

    DataCenter(int id, int numOfServers);

    int getLinuxServerCounter();

    int getWindowsServerCounter();

    StatusType requestServerFromDb(int serverID, int os, int *assignedID);

    StatusType freeServerFromDb(int serverID);

    virtual ~DataCenter();
};


#endif //HW2_DATACENTER_H
