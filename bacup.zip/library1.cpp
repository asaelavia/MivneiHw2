//
// Created by Avia on 28/11/2019.
//
#include <cstdlib>
#include "library1.h"


#include"library1.h"
#include"DataCenterManager.h"

void *Init() {
    DataCenterManager *DS = new DataCenterManager();
    return (void *) DS;
}

StatusType AddDataCenter(void *DS, int dataCenterID, int numOfServers) {
    if ((numOfServers <= 0) || (dataCenterID <= 0) || (DS == NULL))
        return INVALID_INPUT;
    return SUCCESS;
}

StatusType RequestServer(void *DS, int dataCenterID, int serverID, int os,
                         int *assignedID) {

    return INVALID_INPUT;
}
