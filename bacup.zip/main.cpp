#include <iostream>
#include <vector>
#include "DataCenter.h"

int main() {
    DataCenter a(0, 5);
    int b = 3;
    a.requestServerFromDb(1, 1, &b);
    a.requestServerFromDb(1, 0, &b);
    a.requestServerFromDb(0, 1, &b);
    a.freeServerFromDb(2);
    a.freeServerFromDb(1);
    a.freeServerFromDb(0);
    std::cout << b << std::endl;
    return 0;
}